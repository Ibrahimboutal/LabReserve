import { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Paper,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  CircularProgress,
  Alert,
  TableContainer,
  FormControl,
  MenuItem,
  InputLabel,
  Select,
} from '@mui/material';
import { supabase } from '@/lib/supabase';
import { Lab } from '@/types';
import { useAuth } from '@/hooks/useAuth';

export default function LabManagement() {
  const [lab, setLab] = useState<Lab[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedLab, setSelectedLab] = useState<Lab | null>(null);
  const [newName, setNewName] = useState<string>('');
  const [newManager, setNewManager] = useState<string>('');
  const [newLocation, setNewLocation] = useState<string>('');
  const [newDescription, setNewDescription] = useState<string>('');
  const [newFeatures, setNewFeatures] = useState('');
  const [newStatus, setNewStatus] = useState<'available' | 'occupied' | 'maintenance'>('available');
  const [newCapacity, setNewCapacity] = useState<number | null>(null);
  const [users, setUsers] = useState<any[]>([]);
  const { user: authUser } = useAuth(); // Get current user from auth context

  // Separate state for each dialog
  const [openLabDialog, setOpenLabDialog] = useState(false);
  const [labFormData, setLabFormData] = useState({
    name: '',
    location: '',
    manager_id: '',
    capacity: '',
    status: '',
    features: [] as string[],
    description: '',
  });

  useEffect(() => {
    fetchLabs();
    fetchUsers();
  }, []);

  const fetchLabs = async () => {
    try {
      const { data, error } = await supabase
        .from('lab')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      setLab(data || []);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('id, email, role')
        .eq('role', 'lab_manager')
        .order('created_at', { ascending: false });
      if (error) throw error;
      setUsers(data || []);
    } catch (error: any) {
      setError(error.message);
    }
  };

  const handleEditLab = (lab: Lab) => {

    
    setSelectedLab(lab);
    setNewName(lab.name);
    setNewManager(lab.manager_id);
    setNewLocation(lab.location);
    setNewCapacity(lab.capacity);
    setNewDescription(lab.description);
    setNewFeatures(lab.features);
    setNewStatus(lab.status);

    setDialogOpen(true);
  };


  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
  
    // Validate required fields
    if (!selectedLab || !newName || !newManager || !newLocation || !newCapacity || !newDescription || !newFeatures || !newStatus) {
      setError('Please fill all fields');
      console.error('Validation failed:', {
        selectedLab,
        newName,
        newManager,
        newLocation,
        newCapacity,
        newDescription,
        newFeatures,
        newStatus,
      });
      return;
    }
  
    try {
      console.log('Updating lab with ID:', selectedLab.id);
  
      const { data, error } = await supabase
        .from('lab')
        .update({
          name: newName,
          manager_id: newManager,
          location: newLocation,
          capacity: newCapacity,
          description: newDescription,
          features: newFeatures,
          status: newStatus,
        })
        .eq('id', selectedLab.id);
  
      console.log('Update Response:', { data, error });
  
      if (error) {
        throw error;
      }
  
      // Close the dialog and refresh the labs list
      setDialogOpen(false);
      fetchLabs();
    } catch (error: any) {
      console.error('Error updating lab:', error.message);
      setError(error.message);
    }
  };
  

  const handleCreateLab = async () => {
    try {
      // Check if current user has admin privileges
      if (!authUser || authUser.role !== 'admin') {
        throw new Error('Admin privileges required');
      }

      // Validate required fields
      if (
        !labFormData.name ||
        !labFormData.location ||
        !labFormData.manager_id ||
        !labFormData.capacity ||
        !labFormData.description ||
        !labFormData.features ||
        !labFormData.status
      ) {
        throw new Error('Please fill all required fields');
      }

      // Convert capacity to a number
      const capacity = Number(labFormData.capacity);
      if (isNaN(capacity) || capacity <= 0) {
        throw new Error('Capacity must be a positive number');
      }

      // Create lab entry in the database
      const { data: labData, error: labError } = await supabase
        .from('lab')
        .insert([
          {
            name: labFormData.name,
            location: labFormData.location,
            manager_id: labFormData.manager_id,
            capacity: capacity,
            description: labFormData.description,
            features: labFormData.features.map((feature: string) => feature.trim()),
            status: labFormData.status,
          },
        ])
        .select();

      if (labError) throw labError;

      // Success handling
      setOpenLabDialog(false);

      // Reset form fields
      setLabFormData({
        name: '',
        location: '',
        manager_id: '',
        capacity: '',
        description: '',
        features: [],
        status: '',
      });

      // Fetch updated labs
      fetchLabs();

      // Optional: Show success notification
      console.log('Lab created successfully:', labData);
    } catch (error) {
      if (error instanceof Error) {
        console.error('Error creating lab:', error.message);
        alert(`Error: ${error.message}`);
      } else {
        console.error('Error creating lab:', error);
        alert('An unexpected error occurred.');
      }
    }
  };

  if (loading) return <CircularProgress />;
  if (error) return <Alert severity="error">{error}</Alert>;

  return (
    <Box>
      {error && <Alert severity="error">{error}</Alert>}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6">Lab Management</Typography>
        <Button variant="contained" color="primary" onClick={() => setOpenLabDialog(true)}>
          Create Lab
        </Button>
      </Box>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Location</TableCell>
              <TableCell>Manager</TableCell>
              <TableCell>Capacity</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Features</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {lab.map((lab) => (
              <TableRow key={lab.id}>
                <TableCell>{lab.name}</TableCell>
                <TableCell>{lab.location}</TableCell>
                <TableCell>{users.find((user) => user.id === lab.manager_id)?.email || 'Unassigned'}</TableCell>
                <TableCell>{lab.capacity}</TableCell>
                <TableCell>{lab.description}</TableCell>
                <TableCell>{lab.features}</TableCell>
                <TableCell>{lab.status}</TableCell>
                <TableCell>
                  <Button variant="contained" color="primary" onClick={() => handleEditLab(lab)}>
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Edit Lab Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
        <DialogTitle>Edit Lab</DialogTitle>
        <DialogContent>
          <TextField
            label="Name"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            fullWidth
            margin="normal"
          />
          <FormControl fullWidth margin="normal">
            <InputLabel>Manager</InputLabel>
            <Select
              value={newManager}
              onChange={(e) => setNewManager(e.target.value as string)}
              label="Manager"
            >
              {users.map((user) => (
                <MenuItem key={user.id} value={user.id}>
                  {user.email}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            label="Location"
            value={newLocation}
            onChange={(e) => setNewLocation(e.target.value)}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Capacity"
            value={newCapacity}
            onChange={(e) => setNewCapacity(Number(e.target.value))}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Description"
            value={newDescription}
            onChange={(e) => setNewDescription(e.target.value)}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Features"
            value={newFeatures}
            onChange={(e) => setNewFeatures(e.target.value)} // Store the raw input as a string
            fullWidth
            margin="normal"
          />
          <FormControl fullWidth margin="normal">
            <InputLabel>Status</InputLabel>
            <Select
              value={newStatus}
              onChange={(e) => setNewStatus(e.target.value as 'available' | 'occupied' | 'maintenance')}
              label="Status"
            >
              <MenuItem value="available">Available</MenuItem>
              <MenuItem value="occupied">Occupied</MenuItem>
              <MenuItem value="maintenance">Maintenance</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSubmit} color="primary">
            Save
          </Button>
        </DialogActions>
      </Dialog>

      {/* Create Lab Dialog */}
      <Dialog open={openLabDialog} onClose={() => setOpenLabDialog(false)}>
        <DialogTitle>Create Lab</DialogTitle>
        <DialogContent>
          {/* Name Field */}
          <TextField
            margin="dense"
            label="Name"
            fullWidth
            required
            value={labFormData.name}
            onChange={(e) => setLabFormData({ ...labFormData, name: e.target.value })}
          />
          {/* Location Field */}
          <TextField
            margin="dense"
            label="Location"
            fullWidth
            required
            value={labFormData.location}
            onChange={(e) => setLabFormData({ ...labFormData, location: e.target.value })}
          />
          {/* Manager ID Dropdown */}
          <FormControl fullWidth margin="dense" required>
            <InputLabel>Manager ID</InputLabel>
            <Select
              label="Manager ID"
              value={labFormData.manager_id}
              onChange={(e) => setLabFormData({ ...labFormData, manager_id: e.target.value })}
            >
              {users.map((user) => (
                <MenuItem key={user.id} value={user.id}>
                  {user.email}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            margin="dense"
            label="Capacity"
            type="number"
            fullWidth
            required
            value={labFormData.capacity}
            onChange={(e) => setLabFormData({ ...labFormData, capacity: e.target.value })}
            InputProps={{
              inputProps: { min: 1 },
            }}
          />
          <TextField
            label="Description"
            value={labFormData.description}
            onChange={(e) => setLabFormData({ ...labFormData, description: e.target.value })}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Features"
            value={labFormData.features}
            onChange={(e) => setLabFormData({ ...labFormData, features: e.target.value.split(',') })}
            fullWidth
            margin="normal"
          />
          <FormControl fullWidth margin="normal">
            <InputLabel>Status</InputLabel>
            <Select
              value={labFormData.status}
              onChange={(e) =>
                setLabFormData({ ...labFormData, status: e.target.value as 'available' | 'occupied' | 'maintenance' })
              }
              label="Status"
            >
              <MenuItem value="available">Available</MenuItem>
              <MenuItem value="occupied">Occupied</MenuItem>
              <MenuItem value="maintenance">Maintenance</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenLabDialog(false)}>Cancel</Button>
          <Button onClick={handleCreateLab} color="primary">
            Create Lab
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}