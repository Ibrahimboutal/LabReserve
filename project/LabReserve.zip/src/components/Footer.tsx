import { Box, Container, Grid, Typography, Link, IconButton, Stack } from '@mui/material';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';
import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';


export default function Footer() {
  return (
    
    <Box
    component="footer"
    sx={{
      bgcolor: (theme) => theme.palette.primary.main,
      color: (theme) => theme.palette.primary.contrastText,

      py: 6,
      mt: 'auto',
    }}
  
    >
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              LabReserve
            </Typography>
            <Typography variant="body2">
              Streamlining laboratory equipment management and reservations for research institutions worldwide.
            </Typography>
            <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
              <IconButton color="inherit" aria-label="LinkedIn">
                <LinkedInIcon />
              </IconButton>
              <IconButton color="inherit" aria-label="Twitter">
                <TwitterIcon />
              </IconButton>
              <IconButton color="inherit" aria-label="Facebook">
                <FacebookIcon />
              </IconButton>
              <IconButton color="inherit" aria-label="Instagram">
                <InstagramIcon />
              </IconButton>
            </Stack>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              Quick Links
            </Typography>
            <Box component="ul" sx={{ listStyle: 'none', p: 0, m: 0 }}>
              <Box component="li" sx={{ mb: 1 }}>
                <Link href="/about" color="inherit" underline="hover">
                  About Us
                </Link>
              </Box>
              <Box component="li" sx={{ mb: 1 }}>
                <Link href="/equipment" color="inherit" underline="hover">
                  Equipment
                </Link>
              </Box>
              <Box component="li" sx={{ mb: 1 }}>
                <Link href="/login" color="inherit" underline="hover">
                  Login
                </Link>
              </Box>
              <Box component="li" sx={{ mb: 1 }}>
                <Link href="/register" color="inherit" underline="hover">
                  Register
                </Link>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              Contact Us
            </Typography>
            <Typography variant="body2" paragraph>
              123 Innovation Way
              <br />
              Dalian, CH 02142
            </Typography>
            <Typography variant="body2" paragraph>
              Email: info@labreserve.com
              <br />
              Phone: (800) 555-LABS
            </Typography>
          </Grid>
        </Grid>
        <Box sx={{ mt: 4, pt: 2, borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <Typography variant="body2" align="center">
            © {new Date().getFullYear()} LabReserve. All rights reserved.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
}