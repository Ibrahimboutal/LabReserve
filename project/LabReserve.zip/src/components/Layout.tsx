import { Box, AppBar, Toolbar, Typography, Button, IconButton } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useTheme } from '../contexts/ThemeContext';
import NotificationCenter from './NotificationCenter';
import MessageCenter from './MessageCenter';
import Brightness4Icon from '@mui/icons-material/Brightness4';
import Brightness7Icon from '@mui/icons-material/Brightness7';
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { mode, toggleColorMode } = useTheme();

  const handleLogout = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <Box sx={{ 
      display: 'flex',
      flexDirection: 'column',
      minHeight: '100vh' }}>

      <AppBar position="static">
        <Toolbar>
          <Typography 
            variant="h6" 
            component="div" 
            sx={{ flexGrow: 1, cursor: 'pointer' }}
            onClick={() => navigate('/')}
          >
            LabReserve
          </Typography>
          <IconButton 
            sx={{ mr: 2 }} 
            onClick={toggleColorMode} 
            color="inherit"
          >
            {mode === 'dark' ? <Brightness7Icon /> : <Brightness4Icon />}
            </IconButton>
           
          <Button color="inherit" onClick={() => navigate('/about')}>
            About
          </Button>
          {user ? (
             
            
            <>
              <NotificationCenter />
              <MessageCenter />
              <Button color="inherit" onClick={() => navigate('/dashboard')}>
                Dashboard
              </Button>
              <Button color="inherit" onClick={() => navigate('/equipment')}>
                Equipment
              </Button>
              <Button color="inherit" onClick={() => navigate('/labs')}>
                Labs
              </Button>
              <Button color="inherit" onClick={() => navigate('/reservations')}>
                Reservations
              </Button>
              {user.role === 'admin' && (
                <Button color="inherit" onClick={() => navigate('/admin')}>
                  Admin
                </Button>
              )}
              {user.role === 'lab_manager' && (
                <Button color="inherit" onClick={() => navigate('/lab_manager')}>
                  Lab Manager
                </Button>
              )}
              
              <Button color="inherit" onClick={() => navigate('/profile')}>
                Profile
              </Button>
              
              <Button color="inherit" onClick={handleLogout}>
                Logout
              </Button>

            </> 
          ) : (
            <>
              <Button color="inherit" onClick={() => navigate('/login')}>
                Login
              </Button>
              <Button color="inherit" onClick={() => navigate('/register')}>
                Register
              </Button>
            </>
          )}
          
        </Toolbar>
      </AppBar>

      <Box
      component="main"
       sx={{ 
        flexGrow: 1,
        p: 3 }}>

        {children}
      </Box>
      <Footer />
    </Box>
  );
}
