import { useState, useEffect } from 'react';
import {
  Box,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  CircularProgress,
  Alert,
  Snackbar,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Select,
  MenuItem,
} from '@mui/material';
import { supabase } from '@/lib/supabase';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import WarningIcon from '@mui/icons-material/Warning';
import { useAuth } from '@/hooks/useAuth';
import { Notification } from '@/types';

export default function NotificationManagement() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<
    (Notification & { users: { email: string; role: string } })[]
  >([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [newNotification, setNewNotification] = useState<Partial<Notification> | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [DialogOpen, setDialogOpen] = useState(false);
  const [notificationToDelete, setNotificationToDelete] = useState<string | null>(null);

  // Fetch notifications on mount
  useEffect(() => {
    fetchNotifications();
    subscribeToNotifications();
  }, []);

  // Fetch notifications from Supabase
  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('notifications')
        .select(`
          *,
          users: user_id(email, role)
        `)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setNotifications(data || []);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Subscribe to real-time updates
  const subscribeToNotifications = () => {
    const subscription = supabase
      .channel('notifications')
      
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notifications',
        },
        async (payload) => {
          console.log('Notification change detected:', payload);

          // Validate payload
          if (!payload.new || !(payload.new as Notification).id) {
            console.warn('Invalid payload received:', payload);
            return;
          }

          if (payload.eventType === 'INSERT') {
            const existingNotification = notifications.find((n) => n.id === payload.new.id);
            if (existingNotification) {
              console.warn('Duplicate notification ID detected:', payload.new.id);
              return; // Skip adding duplicates
            }

            // Fetch the email and role for the new notification
            const { data: userData } = await supabase
              .from('users')
              .select('email, role')
              .eq('id', payload.new.user_id)
              .single();

            setNotifications((prev) => [
              {
                ...(payload.new as Notification),
                users: { email: userData?.email || '', role: userData?.role || '' },
              },
              ...prev,
            ]);
          } else if (payload.eventType === 'UPDATE') {
            setNotifications((prev) =>
              prev.map((n) =>
                n.id === payload.new.id
                  ? ({
                      ...payload.new,
                      users: n.users,
                    } as Notification & { users: { email: string; role: string } })
                  : n
              )
            );
          } else if (payload.eventType === 'DELETE') {
            setNotifications((prev) => prev.filter((n) => n.id !== payload.old.id));
          }
        }
      )
      .subscribe();
     

    return () => {
      subscription.unsubscribe();
    };
  };

  // Create or update a notification
  const handleCreateOrUpdateNotification = async () => {
    if (!newNotification || !user) return;
    const notificationData = {
      ...newNotification,
      user_id: user.id,
    };

    try {
      if (isEditing && newNotification.id) {
        const { error } = await supabase
          .from('notifications')
          .update(notificationData)
          .eq('id', newNotification.id);
        if (error) throw error;
        setSnackbarMessage('Notification updated successfully!');
      } else {
        const { error } = await supabase.from('notifications').insert([notificationData]);
        if (error) throw error;
        setSnackbarMessage('Notification created successfully!');
      }
      fetchNotifications();
      setIsEditing(false);
      setNewNotification(null);
      setSnackbarOpen(true);
      setDialogOpen(false);
    } catch (error: any) {
      setError(error.message);
    }
  };

  // Handle editing a notification
  const handleEditNotification = (notification: Notification & { users: { email: string; role: string } }) => {
    setNewNotification(notification);
    setIsEditing(true);
    setDialogOpen(true);
  };

  // Handle deleting a notification
  const handleDeleteNotification = async () => {
    if (!notificationToDelete) return;
    try {
      const { error } = await supabase
        .from('notifications')
        .delete()
        .eq('id', notificationToDelete);
      if (error) throw error;
      setSnackbarMessage('Notification deleted successfully!');
      setSnackbarOpen(true);
      fetchNotifications();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setDeleteDialogOpen(false);
      setNotificationToDelete(null);
    }
  };

  // Notification type options
  const notificationTypes = ['Info', 'Warning', 'Error', 'Success'];

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ p: 3 }}>
        <Typography variant="h4" gutterBottom>
          Notification Management
        </Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={() => {
            setDialogOpen(true);
            setIsEditing(false);
            setNewNotification(null);
          }}
        >
          Create Notification
        </Button>
      </Box>

      {/* Error Handling */}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {/* Dialog for Creating/Updating Notifications */}
      <Dialog
        open={DialogOpen}
        onClose={() => {
          setDialogOpen(false);
          setNewNotification(null);
          setIsEditing(false);
        }}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>{isEditing ? 'Edit Notification' : 'Create Notification'}</DialogTitle>
        <DialogContent>
          <TextField
            label="Title"
            value={newNotification?.title || ''}
            onChange={(e) => setNewNotification({ ...newNotification, title: e.target.value })}
            fullWidth
            sx={{ mb: 2 }}
          />
          <TextField
            label="Message"
            value={newNotification?.message || ''}
            onChange={(e) => setNewNotification({ ...newNotification, message: e.target.value })}
            fullWidth
            multiline
            rows={4}
            sx={{ mb: 2 }}
          />
          <Select
            value={newNotification?.type || ''}
            onChange={(e) => setNewNotification({ ...newNotification, type: e.target.value })}
            fullWidth
            displayEmpty
            sx={{ mb: 2 }}
          >
            <MenuItem value="" disabled>
              Select Notification Type
            </MenuItem>
            {notificationTypes.map((type) => (
              <MenuItem key={type} value={type}>
                {type}
              </MenuItem>
            ))}
          </Select>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)} color="primary">
            Cancel
          </Button>
          <Button
            onClick={handleCreateOrUpdateNotification}
            color="primary"
            startIcon={isEditing ? <CheckCircleIcon /> : undefined}
            autoFocus
          >
            {isEditing ? 'Update Notification' : 'Create Notification'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Loading Indicator */}
      {loading ? (
        <CircularProgress />
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Title</TableCell>
                <TableCell>Message</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Created At</TableCell>
                <TableCell>Created By</TableCell>
                <TableCell>Role</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {notifications.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    No notifications available.
                  </TableCell>
                </TableRow>
              ) : (
                notifications.map((notification) => (
                  <TableRow key={notification.id}>
                    <TableCell>{notification.title}</TableCell>
                    <TableCell>{notification.message}</TableCell>
                    <TableCell>{notification.type}</TableCell>
                    <TableCell>{new Date(notification.created_at).toLocaleString()}</TableCell>
                    <TableCell>{notification.users.email || 'Unknown'}</TableCell>
                    <TableCell>{notification.users.role || 'Unknown'}</TableCell>
                    <TableCell align="right">
                      <IconButton color="primary" onClick={() => handleEditNotification(notification)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        color="error"
                        onClick={() => {
                          setNotificationToDelete(notification.id);
                          setDeleteDialogOpen(true);
                        }}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Snackbar for Success Messages */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        message={snackbarMessage}
      />

      {/* Confirmation Dialog for Deletion */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)}>
        <DialogTitle>Delete Notification</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <WarningIcon color="warning" sx={{ mr: 2 }} />
            <Typography>Are you sure you want to delete this notification?</Typography>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)} color="primary">
            Cancel
          </Button>
          <Button onClick={handleDeleteNotification} color="error" autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}