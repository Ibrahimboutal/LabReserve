import { Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

interface PrivateRouteProps {
  children: React.ReactNode;
  allowedRoles?: string[]; // Optional prop for role-based access
}

export default function PrivateRoute({ children, allowedRoles }: PrivateRouteProps) {
  const { user } = useAuth();

  // Redirect unauthenticated users to the login page
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Check if the user has the required role(s)
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Redirect unauthorized users to a restricted or home page
    return <Navigate to="/" replace />;
  }

  // Render the protected content if the user is authenticated and authorized
  return <>{children}</>;
}