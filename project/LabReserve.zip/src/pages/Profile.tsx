import { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Box,
  TextField,
  Button,
  Avatar,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  Card,
  CardContent,
  Chip,
  Tab,
  Tabs,
  LinearProgress,
  Switch,
} from '@mui/material';
import {
  Security as SecurityIcon,
  Notifications as NotificationsIcon,
  History as HistoryIcon,
  Science as ScienceIcon,
  Settings as SettingsIcon,
} from '@mui/icons-material';
import { format, parseISO } from 'date-fns';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';
import { useNotification } from '@/hooks/useNotification';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';

const departments = [
  'Chemistry',
  'Physics',
  'Biology',
  'Engineering',
  'Computer Science',
  'Other',
];

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`profile-tabpanel-${index}`}
      aria-labelledby={`profile-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

export default function Profile() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [passwordDialog, setPasswordDialog] = useState(false);
  const [notificationDialog, setNotificationDialog] = useState(false);
  const [tabValue, setTabValue] = useState(0);
  const { showNotification, NotificationComponent } = useNotification();
  const [stats, setStats] = useState({
    total: 0,
    approved: 0,
    pending: 0,
    denied: 0,
    cancelled: 0,
    completed: 0,
  });
  const [formData, setFormData] = useState({
    email: user?.email || '',
    department: user?.department || '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    notifications: {
      email: true,
      reservationUpdates: true,
      maintenanceAlerts: true,
      systemAnnouncements: true,
    },
  });

  useEffect(() => {
    fetchUserData();
  }, [user]);

  const fetchUserData = async () => {
    if (!user) return;

    try {
      setLoading(true);
      const [activityResponse, statsResponse] = await Promise.all([
        supabase
          .from('reservations')
          .select(`
            *,
            equipment (
              name,
              category
            )
          `)
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(5),
        supabase
          .from('reservations')
          .select('*')
          .eq('user_id', user.id),
      ]);

      if (activityResponse.error) throw activityResponse.error;
      if (statsResponse.error) throw statsResponse.error;

      setRecentActivity(activityResponse.data);

      // Calculate statistics
      const statistics = statsResponse.data.reduce((acc: any, curr) => {
        acc.total++;
        acc[curr.status]++;
        return acc;
      }, {
        total: 0,
        approved: 0,
        pending: 0,
        denied: 0,
        cancelled: 0,
        completed: 0,
      });
      setStats(statistics);

    } catch (error: any) {
      console.error('Error fetching user data:', error);
      setError('Failed to load user data');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      const { error } = await supabase
        .from('users')
        .update({
          department: formData.department,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user?.id);

      if (error) throw error;

      setSuccess('Profile updated successfully');
      showNotification('Profile updated successfully', 'success');
    } catch (error: any) {
      setError(error.message);
      showNotification(error.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChange = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      if (formData.newPassword !== formData.confirmPassword) {
        throw new Error('New passwords do not match');
      }

      const { error } = await supabase.auth.updateUser({
        password: formData.newPassword,
      });

      if (error) throw error;

      setSuccess('Password updated successfully');
      showNotification('Password updated successfully', 'success');

      setPasswordDialog(false);
      setFormData(prev => ({
        ...prev,
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      }));
    } catch (error: any) {
      setError(error.message);
      showNotification(error.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (_: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'success';
      case 'pending':
        return 'warning';
      case 'denied':
        return 'error';
      case 'cancelled':
        return 'default';
      case 'completed':
        return 'info';
      default:
        return 'default';
    }
  };

  const handleSaveNotificationPreferences = () => {
    showNotification('Notification preferences saved', 'success');
    setNotificationDialog(false);
  };
  
  






  if (!user) {
    return (
      <Container sx={{ mt: 4 }}>
        <Alert severity="error">Please log in to view your profile</Alert>
      </Container>
    );
  }

  const pieChartData = [
    { name: 'Approved', value: stats.approved, color: '#4caf50' },
    { name: 'Pending', value: stats.pending, color: '#ff9800' },
    { name: 'Denied', value: stats.denied, color: '#f44336' },
    { name: 'Cancelled', value: stats.cancelled, color: '#9e9e9e' },
    { name: 'Completed', value: stats.completed, color: '#2196f3' },
  ];

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Grid container spacing={3}>
        {/* Profile Overview */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, position: 'relative' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
              <Avatar
                sx={{
                  width: 100,
                  height: 100,
                  bgcolor: 'primary.main',
                  fontSize: '2.5rem',
                  mr: 3,
                }}
              >
                {user.email[0].toUpperCase()}
              </Avatar>
              <Box>
                <Typography variant="h4" gutterBottom>
                  {user.email.split('@')[0]}
                </Typography>
                <Typography color="textSecondary" gutterBottom>
                  {user.email}
                </Typography>
                <Chip
                  label={user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                  color="primary"
                  size="small"
                />
              </Box>
            </Box>

            {/* Quick Stats */}
            <Grid container spacing={3} sx={{ mb: 3 }}>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary" gutterBottom>
                      Total Reservations
                    </Typography>
                    <Typography variant="h4">
                      {stats.total}
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={100} 
                      sx={{ mt: 2, height: 8, borderRadius: 4 }}
                    />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary" gutterBottom>
                      Approved
                    </Typography>
                    <Typography variant="h4" color="success.main">
                      {stats.approved}
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={(stats.approved / stats.total) * 100} 
                      color="success"
                      sx={{ mt: 2, height: 8, borderRadius: 4 }}
                    />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary" gutterBottom>
                      Pending
                    </Typography>
                    <Typography variant="h4" color="warning.main">
                      {stats.pending}
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={(stats.pending / stats.total) * 100} 
                      color="warning"
                      sx={{ mt: 2, height: 8, borderRadius: 4 }}
                    />
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="textSecondary" gutterBottom>
                      Success Rate
                    </Typography>
                    <Typography variant="h4" color="info.main">
                      {stats.total ? Math.round((stats.approved / stats.total) * 100) : 0}%
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={stats.total ? (stats.approved / stats.total) * 100 : 0} 
                      color="info"
                      sx={{ mt: 2, height: 8, borderRadius: 4 }}
                    />
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            {/* Tabs */}
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs value={tabValue} onChange={handleTabChange}>
                <Tab icon={<SettingsIcon />} label="Settings" />
                <Tab icon={<HistoryIcon />} label="Activity" />
                <Tab icon={<ScienceIcon />} label="Statistics" />
              </Tabs>
            </Box>

            {/* Settings Tab */}
            <TabPanel value={tabValue} index={0}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Profile Information
                  </Typography>
                  <TextField
                    margin="normal"
                    fullWidth
                    label="Email"
                    value={formData.email}
                    disabled
                  />
                  <TextField
                    margin="normal"
                    fullWidth
                    select
                    label="Department"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                  >
                    {departments.map((dept) => (
                      <MenuItem key={dept} value={dept}>
                        {dept}
                      </MenuItem>
                    ))}
                  </TextField>

                  {error && (
                    <Alert severity="error" sx={{ mt: 2 }}>
                      {error}
                    </Alert>
                  )}
                  {success && (
                    <Alert severity="success" sx={{ mt: 2 }}>
                      {success}
                    </Alert>
                  )}

                  <Box sx={{ mt: 3 }}>
                    <Button
                      variant="contained"
                      onClick={handleUpdateProfile}
                      disabled={loading}
                      fullWidth
                    >
                      {loading ? <CircularProgress size={24} /> : 'Update Profile'}
                    </Button>
                  </Box>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Security & Notifications
                  </Typography>
                  <Box sx={{ mb: 3 }}>
                    <Button
                      variant="outlined"
                      startIcon={<SecurityIcon />}
                      onClick={() => setPasswordDialog(true)}
                      fullWidth
                      sx={{ mb: 2 }}
                    >
                      Change Password
                    </Button>
                    <Button
                      variant="outlined"
                      startIcon={<NotificationsIcon />}
                      onClick={() => setNotificationDialog(true)}
                      fullWidth
                    >
                      Notification Preferences
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </TabPanel>

            {/* Activity Tab */}
            <TabPanel value={tabValue} index={1}>
              <Typography variant="h6" gutterBottom>
                Recent Activity
              </Typography>
              <List>
                {recentActivity.map((activity) => (
                  <ListItem key={activity.id}>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography variant="subtitle1">
                            Reserved {activity.equipment.name}
                          </Typography>
                          <Chip
                            label={activity.status}
                            size="small"
                            color={getStatusColor(activity.status)}
                          />
                        </Box>
                      }
                      secondary={
                        <>
                          <Typography variant="body2" color="text.secondary">
                            {format(parseISO(activity.created_at), 'PPpp')}
                          </Typography>
                          <Typography variant="body2">
                            {format(parseISO(activity.start_time), 'PPp')} - {format(parseISO(activity.end_time), 'p')}
                          </Typography>
                        </>
                      }
                    />
                  </ListItem>
                ))}
                {recentActivity.length === 0 && (
                  <ListItem>
                    <ListItemText
                      primary="No recent activity"
                      secondary="Your reservation history will appear here"
                    />
                  </ListItem>
                )}
              </List>
            </TabPanel>

            {/* Statistics Tab */}
            <TabPanel value={tabValue} index={2}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Reservation Distribution
                  </Typography>
                  <Box sx={{ height: 300 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieChartData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          label
                          labelLine={false}
                          animationDuration={500}
                          animationEasing="ease-in-out"
                          isAnimationActive={true}
                        >
                          {pieChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <RechartsTooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>
                    Usage Statistics
                  </Typography>
                  <List>
                    <ListItem>
                      <ListItemText
                        primary="Success Rate"
                        secondary={`${stats.total ? Math.round((stats.approved / stats.total) * 100) : 0}% of your reservations are approved`}
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText
                        primary="Average Response Time"
                        secondary="Usually within 24 hours"
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText
                        primary="Most Reserved Equipment"
                        secondary="Microscope XYZ (5 times)"
                      />
                    </ListItem>
                  </List>
                </Grid>
              </Grid>
            </TabPanel>
          </Paper>
        </Grid>
      </Grid>

      {/* Password Change Dialog */}
      <Dialog open={passwordDialog} onClose={() => setPasswordDialog(false)}>
        <DialogTitle>Change Password</DialogTitle>
        <DialogContent>
          <TextField
            margin="dense"
            label="Current Password"
            type="password"
            fullWidth
            value={formData.currentPassword}
            onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
          />
          <TextField
            margin="dense"
            label="New Password"
            type="password"
            fullWidth
            value={formData.newPassword}
            onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
          />
          <TextField
            margin="dense"
            label="Confirm New Password"
            type="password"
            fullWidth
            value={formData.confirmPassword}
            onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPasswordDialog(false)}>Cancel</Button>
          <Button onClick={handlePasswordChange} variant="contained">
            Update Password
          </Button>
        </DialogActions>
      </Dialog>

      {/* Notification Preferences Dialog */}
      <Dialog open={notificationDialog} onClose={() => setNotificationDialog(false)}>
        <DialogTitle>Notification Preferences</DialogTitle>
        <DialogContent>
          <List>
            <ListItem>
              <ListItemText
                primary="Email Notifications"
                secondary="Receive notifications via email"
              />
              <Switch
                checked={formData.notifications.email}
                onChange={(e) => setFormData({
                  ...formData,
                  notifications: {
                    ...formData.notifications,
                    email: e.target.checked
                  }
                })}
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="Reservation Updates"
                secondary="Get notified about changes to your reservations"
              />
              <Switch
                checked={formData.notifications.reservationUpdates}
                onChange={(e) => setFormData({
                  ...formData,
                  notifications: {
                    ...formData.notifications,
                    reservationUpdates: e.target.checked
                  }
                })}
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="Maintenance Alerts"
                secondary="Receive alerts about equipment maintenance"
              />
              <Switch
                checked={formData.notifications.maintenanceAlerts}
                onChange={(e) => setFormData({
                  ...formData,
                  notifications: {
                    ...formData.notifications,
                    maintenanceAlerts: e.target.checked
                  }
                })}
              />
            </ListItem>
            <ListItem>
              <ListItemText
                primary="System Announcements"
                secondary="Get important system updates and announcements"
              />
              <Switch
                checked={formData.notifications.systemAnnouncements}
                onChange={(e) => setFormData({
                  ...formData,
                  notifications: {
                    ...formData.notifications,
                    systemAnnouncements: e.target.checked
                  }
                })}
              />
            </ListItem>
          </List>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setNotificationDialog(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveNotificationPreferences}>
            Save Preferences
          </Button>
        </DialogActions>
      </Dialog>
       {/* Notification Component */}
      {NotificationComponent()}
    </Container>
  );
}