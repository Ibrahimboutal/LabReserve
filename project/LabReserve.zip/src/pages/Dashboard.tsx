import { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Box,
  CircularProgress,
  Alert,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  Divider,
  Button,
  Chip,
  LinearProgress,
  useTheme,
} from '@mui/material';
import {
  Science as ScienceIcon,
  Event as EventIcon,
  Notifications as NotificationsIcon,
  Assessment as AssessmentIcon,
  ArrowForward as ArrowForwardIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  Pending as PendingIcon,
} from '@mui/icons-material';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';
import { Equipment, Reservation } from '@/types';
import {Lab, lab_reservations} from '@/types';

export default function Dashboard() {
  const { user } = useAuth(); // Get the user from useAuth

  

  const navigate = useNavigate();
  const theme = useTheme();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState({
    totalEquipment: 0,
    activeReservations: 0,
    pendingReservations: 0,
    equipmentUtilization: 0,
  });
  const[labstats, setLabStats] = useState({
    totalLab: 0,
    activeLabReservations: 0,
    pendingLabReservations: 0,
    LabUtilization: 0,
  });

  const [recentReservations, setRecentReservations] = useState<Reservation[]>([]);
  const [recentLabReservations, setRecentLabReservations] = useState<lab_reservations[]>([]);
  const [popularEquipment, setPopularEquipment] = useState<Equipment[]>([]);
  const [popularLabs, setPopularLabs] = useState<Lab[]>([]);
  const [upcomingMaintenance, setUpcomingMaintenance] = useState<any[]>([]);
  const [todayReservations, setTodayReservations] = useState<Reservation[]>([]);
  const [todayLabReservations, setTodayLabReservations] = useState<lab_reservations[]>([]);
  const [upcomingLabMaintenance, setUpcomingLabMaintenance] = useState<any[]>([]);
  
 

  useEffect(() => {
    if (user) {
      fetchDashboardData();
      fetchLabDashboardData();
    }
  }, [ user]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch statistics based on user role
      if (user?.role === 'admin' || user?.role === 'lab_manager') {
        const [equipmentStats, reservationStats, maintenanceStats] = await Promise.all([
          supabase.from('equipment').select('*'),
          supabase.from('reservations').select('*'),
          supabase.from('maintenance_schedules')
            .select(`
              *,
              equipment (
                id,
                name,
                category
              )
            `)
            .gte('scheduled_date', new Date().toISOString())
            .order('scheduled_date', { ascending: true })
            .limit(5),
        ]);

        if (equipmentStats.error) throw equipmentStats.error;
        if (reservationStats.error) throw reservationStats.error;
        if (maintenanceStats.error) throw maintenanceStats.error;

        setStats({
          totalEquipment: equipmentStats.data.length,
          activeReservations: reservationStats.data.filter(r => r.status === 'approved').length,
          pendingReservations: reservationStats.data.filter(r => r.status === 'pending').length,
          equipmentUtilization: calculateUtilization(equipmentStats.data, reservationStats.data),
        });
        
        setUpcomingMaintenance(maintenanceStats.data);
      }

      // Fetch recent reservations
      const { data: reservations, error: reservationsError } = await supabase
        .from('reservations')
        .select(`
          *,
          equipment (
            id,
            name,
            category,
            status,
            lab_id
          )
            
        `)
        .eq(user?.role === 'student' ? 'user_id' : 'status', user?.role === 'student' ? user.id : 'pending')
        .order('created_at', { ascending: false })
        .limit(5);

      if (reservationsError) throw reservationsError;
      setRecentReservations(reservations);

      // Fetch today's reservations
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const { data: todayData, error: todayError } = await supabase
        .from('reservations')
        .select(`
          *,
          equipment (
            id,
            name,
            category,
            status,
            lab_id
          )
        `)
        .gte('start_time', today.toISOString())
        .lt('start_time', tomorrow.toISOString())
        .eq('status', 'approved')
        .eq(user?.role === 'student' ? 'user_id' : 'status', user?.role === 'student' ? user.id : 'approved')
        .order('start_time', { ascending: true });

      if (todayError) throw todayError;
      setTodayReservations(todayData || []);

     
      // Fetch popular equipment
      const { data: equipment, error: equipmentError } = await supabase
        .from('equipment')
        .select('*')
        .eq('status', 'operational')
        .limit(5);

      if (equipmentError) throw equipmentError;
      setPopularEquipment(equipment);

    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };
  

  const fetchLabDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch statistics based on user role
      if (user?.role === 'admin' || user?.role === 'lab_manager') {
        const [labStats, labReservationStats, labMaintenanceStats] = await Promise.all([
          supabase.from('lab').select('*'),
          supabase.from('lab_reservations').select('*'),
          supabase.from('lab_maintenance_schedules')
            .select(`
              *,
              lab (
                id,
                name,
                location
              )
            `)
            .gte('scheduled_date', new Date().toISOString())
            .order('scheduled_date', { ascending: true })
            .limit(5)

        ]);

        if (labStats.error) throw labStats.error;
        if (labReservationStats.error) throw labReservationStats.error;
        if (labMaintenanceStats.error) throw labMaintenanceStats.error;

        setLabStats({
          totalLab: labStats.data.length,
          activeLabReservations: labReservationStats.data.filter(r => r.status === 'approved').length,
          pendingLabReservations: labReservationStats.data.filter(r => r.status === 'pending').length,
          LabUtilization: calculateLabUtilization(labStats.data, labReservationStats.data),
        });
        
        setUpcomingLabMaintenance(labMaintenanceStats.data);
      }

      // Fetch recent reservations
      const { data: labReservations, error: labReservationsError } = await supabase
        .from('lab_reservations')
        .select(`
          *,
           lab (
                id,
                name,
                location
              )
            
        `)
        .eq(user?.role === 'student' ? 'user_id' : 'status', user?.role === 'student' ? user.id : 'pending')
        .order('created_at', { ascending: false })
        .limit(5);

      if (labReservationsError) throw labReservationsError;
      setRecentLabReservations(labReservations);

      // Fetch today's reservations
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const { data: todayLabData, error: todayLabError } = await supabase
        .from('lab_reservations')
        .select(`
          *,
          lab (
            id,
            name,
            location
          )
        `)
        .gte('start_time', today.toISOString())
        .lt('start_time', tomorrow.toISOString())
        .eq('status', 'approved')
        .eq(user?.role === 'student' ? 'user_id' : 'status', user?.role === 'student' ? user.id : 'approved')
        .order('start_time', { ascending: true });
        if (todayLabError) throw todayLabError;
        setTodayLabReservations(todayLabData || []);

     
      // Fetch popular labs
    const { data: labs, error: labsError } = await supabase
        .from('lab')
        .select('*')
        .eq('status', 'available')
        .limit(5);

      if (labsError) throw labsError;
      setPopularLabs(labs);
     }
      catch (error: any) {
        setError(error.message);
     }
      finally {
        setLoading(false);
    }
    
  };


  const calculateUtilization = (equipment: Equipment[], reservations: Reservation[]) => {
    // If there's no equipment, return 0% utilization
    if (equipment.length === 0) return 0;
  
    // Calculate the total number of equipment units by summing up their quantities
    const totalEquipmentUnits = equipment.reduce((total, eq) => total + eq.quantity, 0);
  
    // Calculate the total number of units reserved in completed reservations
    const totalReservedUnits = reservations
      .filter(r => r.status === 'completed') // Only consider completed reservations
      .reduce((total, r) => total + (r.quantity || 1), 0); // Sum up quantity (default to 1 if not specified)
  
    // Calculate utilization as a percentage, rounding to the nearest integer
    return Math.round((totalReservedUnits / totalEquipmentUnits) * 100);
  };

  const calculateLabUtilization = (labs: Lab[], labReservations: lab_reservations[]) => {
    if (labs.length === 0) return 0;

    // Get the current date and the date 7 days ago
    const currentDate = new Date();
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(currentDate.getDate() - 7);

    // Filter reservations that occurred in the last 7 days
    const recentReservations = labReservations.filter(reservation => {
        const reservationDate = new Date(reservation.start_time); // Assuming 'start_time' is the correct property in lab_reservations
        return reservationDate >= sevenDaysAgo && reservation.status === 'completed';
    });

    // Extract unique lab IDs from the recent reservations
    const reservedLabIds = new Set(recentReservations.map(reservation => reservation.lab_id));

    // Calculate the number of unique labs reserved in the last 7 days
    const reservedLabsCount = reservedLabIds.size;

    // Calculate utilization percentage
    return Math.round((reservedLabsCount / labs.length) * 100);
};

  const handleReserveEquipment = (equipmentId: string) => {
    navigate(`/equipment?reserve=${equipmentId}`);
  };

  const handleReserveLab = (labId: string) => {
    navigate(`/labs?reserve=${labId}`);
  };

  const handleReviewReservation = (reservationId: string) => {
    navigate(`/admin?tab=5&reservation=${reservationId}`);
    navigate(`/lab_manager?tab=3&reservation=${reservationId}`);
  };

  const handleReviewLabReservation = (labReservationId: string) => {
    navigate(`/admin?tab=5&labReservation=${labReservationId}`);
    navigate(`/lab_manager?tab=3&labReservation=${labReservationId}`);
    
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircleIcon color="success" />;
      case 'pending':
        return <PendingIcon color="warning" />;
      case 'denied':
      case 'cancelled':
        return <CancelIcon color="error" />;
      case 'completed':
        return <CheckCircleIcon color="success" />;
      default:

        return null;
    }
  };
      



  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Container>
    );
  }

  if (error) {
    return (
      <Container sx={{ mt: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" component="h1" fontWeight="bold">
          Welcome, {user?.email?.split('@')[0]}
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          {format(new Date(), 'EEEE, MMMM d, yyyy')}
        </Typography>
      </Box>

      {/* Equipment Statistics Cards */}
      {(user?.role === 'admin' || user?.role === 'lab_manager') && (
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              height: '100%', 
              transition: 'transform 0.2s', 
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 4 } 
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ 
                    bgcolor: 'primary.light', 
                    borderRadius: '50%', 
                    p: 1, 
                    mr: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <ScienceIcon color="primary" />
                  </Box>
                  <Typography color="text.secondary">Total Equipment</Typography>

                </Box>

                <Typography variant="h4" fontWeight="bold">{stats.totalEquipment}</Typography>
                <Button 
                  size="small" 
                  endIcon={<ArrowForwardIcon />}
                  onClick={() => navigate('/equipment')}
                  sx={{ mt: 1 }}
                >
                  View All
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              height: '100%', 
              transition: 'transform 0.2s', 
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 4 } 
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ 
                    bgcolor: 'success.light', 
                    borderRadius: '50%', 
                    p: 1, 
                    mr: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <EventIcon color="success" />
                  </Box>
                  <Typography color="text.secondary">Active Reservations</Typography>
                </Box>
                <Typography variant="h4" fontWeight="bold">{stats.activeReservations}</Typography>
                <Button 
                  size="small" 
                  endIcon={<ArrowForwardIcon />}
                  onClick={() => {
                    if (user?.role === 'admin')
                    navigate('/admin?tab=5')
                    else if (user?.role === 'lab_manager') {
                      navigate('/lab_manager?tab=3');
                    }
                  }}
                  sx={{ mt: 1 }}
                >
                  Manage
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              height: '100%', 
              transition: 'transform 0.2s', 
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 4 } 
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ 
                    bgcolor: 'warning.light', 
                    borderRadius: '50%', 
                    p: 1, 
                    mr: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <NotificationsIcon color="warning" />
                  </Box>
                  <Typography color="text.secondary">Pending Requests</Typography>
                </Box>
                <Typography variant="h4" fontWeight="bold">{stats.pendingReservations}</Typography>
                <Button 
                  size="small" 
                  endIcon={<ArrowForwardIcon />}
                  onClick={() => {
                    if (user?.role === 'admin') {
                      navigate('/admin?tab=5&filter=pending');
                    } else if (user?.role === 'lab_manager') {
                      navigate('/lab_manager?tab=3&filter=pending');
                    }
                  }}
                  sx={{ mt: 1 }}
                >
                  Review
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              height: '100%', 
              transition: 'transform 0.2s', 
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 4 } 
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ 
                    bgcolor: 'info.light', 
                    borderRadius: '50%', 
                    p: 1, 
                    mr: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <AssessmentIcon color="info" />
                  </Box>
                  <Typography color="text.secondary">Equipment Utilization</Typography>
                </Box>
                <Typography variant="h4" fontWeight="bold">{stats.equipmentUtilization}%</Typography>
                <Box sx={{ mt: 1, mb: 1 }}>
                  <LinearProgress 
                    variant="determinate" 
                    value={stats.equipmentUtilization} 
                    color={
                      stats.equipmentUtilization > 75 ? "success" : 
                      stats.equipmentUtilization > 40 ? "info" : "warning"

                    }
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

      )}
      {/* Lab Statistics Cards*/}
      {(user?.role === 'admin' || user?.role === 'lab_manager') && (
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              height: '100%', 
              transition: 'transform 0.2s', 
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 4 } 
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ 
                    bgcolor: 'primary.light', 
                    borderRadius: '50%', 
                    p: 1, 
                    mr: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <ScienceIcon color="primary" />
                  </Box>
                  <Typography color="text.secondary">Total Labs</Typography>

                </Box>

                <Typography variant="h4" fontWeight="bold">{labstats.totalLab}</Typography>
                <Button 
                  size="small" 
                  endIcon={<ArrowForwardIcon />}
                  onClick={() => navigate('/labs')}
                  sx={{ mt: 1 }}
                >
                  View All
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              height: '100%', 
              transition: 'transform 0.2s', 
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 4 } 
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ 
                    bgcolor: 'success.light', 
                    borderRadius: '50%', 
                    p: 1, 
                    mr: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <EventIcon color="success" />
                  </Box>
                  <Typography color="text.secondary">Active Lab Reservations</Typography>
                </Box>
                <Typography variant="h4" fontWeight="bold">{labstats.activeLabReservations}</Typography>
                <Button 
                  size="small" 
                  endIcon={<ArrowForwardIcon />}
                  onClick={() => {
                    if (user?.role === 'admin')
                      navigate('/admin?tab=5')
                      else if (user?.role === 'lab_manager') {
                        navigate('/lab_manager?tab=3');
                      }
                  }
                  }
                  sx={{ mt: 1 }}
                >
                  Manage 
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              height: '100%', 
              transition: 'transform 0.2s', 
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 4 } 
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ 
                    bgcolor: 'warning.light', 
                    borderRadius: '50%', 
                    p: 1, 
                    mr: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <NotificationsIcon color="warning" />
                  </Box>
                  <Typography color="text.secondary">Pending Lab Requests</Typography>
                </Box>
                <Typography variant="h4" fontWeight="bold">{labstats.pendingLabReservations}</Typography>
                <Button 
                  size="small" 
                  endIcon={<ArrowForwardIcon />}
                  onClick={() => {
                    if (user?.role === 'admin') {
                      navigate('/admin?tab=5&filter=pending');
                    } else if (user?.role === 'lab_manager') {
                      navigate('/lab_manager?tab=3&filter=pending');
                    }
                  }}
                  sx={{ mt: 1 }}
                >
                  Review
                </Button>
              </CardContent>
            </Card>
            </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ 
              height: '100%', 
              transition: 'transform 0.2s', 
              '&:hover': { transform: 'translateY(-4px)', boxShadow: 4 } 
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ 
                    bgcolor: 'info.light', 
                    borderRadius: '50%', 
                    p: 1, 
                    mr: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <AssessmentIcon color="info" />
                  </Box>
                  <Typography color="text.secondary">Lab Utilization</Typography>
                </Box>
                <Typography variant="h4" fontWeight="bold">{labstats.LabUtilization}%</Typography>
                <Box sx={{ mt: 1, mb: 1 }}>
                  <LinearProgress 
                    variant="determinate" 
                    value={labstats.LabUtilization} 
                    color={
                      labstats.LabUtilization > 75 ? "success" : 
                      labstats.LabUtilization > 40 ? "info" : "warning"

                    }
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
              </CardContent>
            </Card>
            </Grid>
        </Grid>
      )}
  



      {/* Today's Equipment Reservations */}
      {todayReservations.length > 0 && (
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom fontWeight="bold">
            Today's Reservations
          </Typography>
          <Paper sx={{ p: 0, overflow: 'hidden' }}>
            <Box sx={{ p: 2, bgcolor: 'primary.main', color: 'primary.contrastText' }}>
              <Typography variant="subtitle1" fontWeight="medium">
                {format(new Date(), 'EEEE, MMMM d')}
              </Typography>
            </Box>
            <List sx={{ p: 0 }}>
              {todayReservations.map((reservation, index) => (
                <Box key={reservation.id}>
                  <ListItem sx={{ py: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                      <Box sx={{ 
                        mr: 2, 
                        p: 1, 
                        bgcolor: 'primary.light', 
                        borderRadius: 1,
                        minWidth: '80px',
                        textAlign: 'center'
                      }}>
                        <Typography variant="body2" fontWeight="bold">
                          {format(new Date(reservation.start_time), 'h:mm a')}
                        </Typography>
                      </Box>
                      <ListItemText
                        primary={
                          <Typography variant="subtitle1" fontWeight="medium">
                            {reservation.equipment?.name || 'Unknown Equipment'}
                            
                          </Typography>
                        }
                        secondary={
                          <Typography variant="body2" color="text.secondary">
                            {format(new Date(reservation.start_time), 'h:mm a')} - {format(new Date(reservation.end_time), 'h:mm a')}
                          </Typography>
                        }
                      />
                      <Chip 
                        label={reservation.equipment?.name || 'Unknown Equipment'} 
                        size="small" 
                        sx={{ mr: 1 }}
                      />
                    </Box>
                  </ListItem>
                  {index < todayReservations.length - 1 && <Divider />}
                </Box>
              ))}
            </List>
          </Paper>
        </Box>
      )}
      {/* Today's lab Reservations */}
      {todayLabReservations.length > 0 && (
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom fontWeight="bold">
            Today's Lab Reservations
          </Typography>
          <Paper sx={{ p: 0, overflow: 'hidden' }}>
            <Box sx={{ p: 2, bgcolor: 'primary.main', color: 'primary.contrastText' }}>
              <Typography variant="subtitle1" fontWeight="medium">
                {format(new Date(), 'EEEE, MMMM d')}
              </Typography>
            </Box>
            <List sx={{ p: 0 }}>
              {todayLabReservations.map((labreservation, index) => (
                <Box key={labreservation.id}>
                  <ListItem sx={{ py: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                      <Box sx={{ 
                        mr: 2, 
                        p: 1, 
                        bgcolor: 'primary.light', 
                        borderRadius: 1,
                        minWidth: '80px',
                        textAlign: 'center'
                      }}>
                        <Typography variant="body2" fontWeight="bold">
                          {format(new Date(labreservation.start_time), 'h:mm a')}
                        </Typography>
                      </Box>
                      <ListItemText
                        primary={
                          <Typography variant="subtitle1" fontWeight="medium">
                            {labreservation.lab?.name || 'Unknown Lab'}
                          </Typography>
                        }
                        secondary={
                          <Typography variant="body2" color="text.secondary">
                            {format(new Date(labreservation.start_time), 'h:mm a')} - {format(new Date(labreservation.end_time), 'h:mm a')}
                          </Typography>
                        }
                      />
                      <Chip 
                        label={labreservation.lab?.name || 'Unknown Lab'} 
                        size="small" 
                        sx={{ mr: 1 }}
                      />
                    </Box>
                  </ListItem>
                  {index < todayLabReservations.length - 1 && <Divider />}
                </Box>
              ))}
            </List>
          </Paper>
        </Box>
      )}

      {/* Main Content Grid */}
      <Grid container spacing={3}>
        {/* Recent Reservations */}
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 0, height: '100%', overflow: 'hidden' }}>
              {/* Header */}
              <Box sx={{ p: 2, bgcolor: theme.palette.primary.main, color: theme.palette.primary.contrastText }}>
                <Typography variant="h6" fontWeight="bold">
                  {user?.role === 'student' ? 'My Recent Equipment Reservations' : 'Pending Equipment Reservations'}
                </Typography>
              </Box>
                <List sx={{ p: 0, height: '300px', overflow: 'auto' }}>
                  {recentReservations.length > 0 ? (
                    recentReservations.map((reservation, index) => (
                      <Box key={reservation.id}>
                        <ListItem sx={{ py: 2 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                            <Box sx={{ mr: 2 }}>{getStatusIcon(reservation.status)}</Box>
                            <ListItemText
                              primary={
                                <Typography variant="subtitle1" fontWeight="medium">
                                  {reservation.equipment?.name || 'Unknown Equipment'}
                                </Typography>
                              }
                              secondary={
                                <Typography variant="body2" color="text.secondary">
                                  {format(new Date(reservation.start_time), 'PPp')} -{' '}
                                  {format(new Date(reservation.end_time), 'PPp')}
                                </Typography>
                              }
                            />
                            {(user?.role === 'admin' || user?.role === 'lab_manager') && (
                              <Button
                                variant="outlined"
                                size="small"
                                onClick={() => handleReviewReservation(reservation.id)}
                              >
                                Review
                              </Button>
                            )}
                          </Box>
                        </ListItem>
                        {index < recentReservations.length - 1 && <Divider />}
                      </Box>
                    ))
                  ) : (
                    <ListItem>
                      <ListItemText
                        primary={
                          <Typography variant="body1" align="center" sx={{ py: 2 }}>
                            No recent equipment reservations
                          </Typography>
                        }
                      />
                    </ListItem>
                  )}
                      {/* View All Button */}
                  <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
                    <Button
                      fullWidth
                      variant="text"
                      endIcon={<ArrowForwardIcon />}
                      onClick={() =>
                        navigate(
                          user?.role === 'student'
                            ? '/reservations'
                            : user?.role === 'admin'
                            ? '/admin?tab=5'
                            : '/lab_manager?tab=3'
                        )
                      }
                    >
                      View All Reservations
                    </Button>
                  </Box>
                </List>

                <Box sx={{ p: 2, bgcolor: theme.palette.primary.main, color: theme.palette.primary.contrastText }}>
                <Typography variant="h6" fontWeight="bold">
                  {user?.role === 'student' ? 'My Recent Lab Reservations' : 'Pending Lab Reservations'}
                </Typography>
              </Box>
                
                <List sx={{ p: 0, height: '300px', overflow: 'auto' }}>
                  {recentLabReservations.length > 0 ? (
                    recentLabReservations.map((labReservation, index) => (
                      <Box key={labReservation.id}>
                        <ListItem sx={{ py: 2 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                            <Box sx={{ mr: 2 }}>{getStatusIcon(labReservation.status)}</Box>
                            <ListItemText
                              primary={
                                <Typography variant="subtitle1" fontWeight="medium">
                                  {labReservation.lab?.name || 'Unknown Lab'}
                                </Typography>
                              }
                              secondary={
                                <Typography variant="body2" color="text.secondary">
                                  {format(new Date(labReservation.start_time), 'PPp')} -{' '}
                                  {format(new Date(labReservation.end_time), 'PPp')}
                                </Typography>
                              }
                            />
                            {(user?.role === 'admin' || user?.role === 'lab_manager') && (
                              <Button
                                variant="outlined"
                                size="small"
                                onClick={() => handleReviewLabReservation(labReservation.id)}
                              >
                                Review
                              </Button>
                            )}
                          </Box>
                        </ListItem>
                        {index < recentLabReservations.length - 1 && <Divider />}
                      </Box>
                    ))
                  ) : (
                    <ListItem>
                      <ListItemText
                        primary={
                          <Typography variant="body1" align="center" sx={{ py: 2 }}>
                            No recent lab reservations
                          </Typography>
                        }
                      />
                    </ListItem>
                  )}
                  {/* View All Button */}
                  <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
                    <Button
                      fullWidth
                      variant="text"
                      endIcon={<ArrowForwardIcon />}
                      onClick={() =>
                        navigate(
                          user?.role === 'student'
                            ? '/reservations'
                            : user?.role === 'admin'
                            ? '/admin?tab=5'
                            : '/lab_manager?tab=3'
                        )
                      }
                    >
                      View All Reservations
                    </Button>
                  </Box>
                </List>
              

              


            </Paper>
          </Grid>
        {/* Available Equipment or Upcoming Maintenance */}
        <Grid item xs={12} md={6}>
          {user?.role === 'student' ? (
            <Paper sx={{ p: 0, height: '100%', overflow: 'hidden' }}>
              <Box sx={{ p: 2, bgcolor: theme.palette.primary.main, color: theme.palette.primary.contrastText }}>
                <Typography variant="h6" fontWeight="bold">
                  Available Equipments
                </Typography>
              </Box>
              <List sx={{ p: 0, height: '300px', overflow: 'auto' }}>
                {popularEquipment.length > 0 ? (
                  popularEquipment.map((equipment, index) => (
                    <Box key={equipment.id}>
                      <ListItem sx={{ py: 2 }}>
                        <ListItemText
                          primary={
                            <Typography variant="subtitle1" fontWeight="medium">
                              {equipment.name}
                            </Typography>
                          }
                          secondary={
                            <Typography variant="body2" color="text.secondary">
                              {equipment.category}
                            </Typography>
                          }
                        />
                        <Button
                          variant="contained"
                          size="small"
                          onClick={() => handleReserveEquipment(equipment.id)}
                        >
                          Reserve
                        </Button>
                      </ListItem>
                      {index < popularEquipment.length - 1 && <Divider />}
                    </Box>
                  ))
                ) : (
                  <ListItem>
                    <ListItemText 
                      primary={
                        <Typography variant="body1" align="center" sx={{ py: 2 }}>
                          No equipment available
                        </Typography>
                      } 
                    />
                  </ListItem>
                )}
                <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
                  <Button 
                    fullWidth 
                    variant="text" 
                    endIcon={<ArrowForwardIcon />}
                    onClick={() => navigate('/equipment')}
                  >
                    Browse All Equipment
                  </Button>
               </Box>
            
              </List>

              <Box sx={{ p: 2, bgcolor: theme.palette.primary.main, color: theme.palette.primary.contrastText }}>
                <Typography variant="h6" fontWeight="bold">
                  Available Labs
                </Typography>
              </Box>
              <List sx={{ p: 0, height: '300px', overflow: 'auto' }}>
                {popularLabs.length > 0 ? (
                  popularLabs.map((lab, index) => (
                    <Box key={lab.id}>
                      <ListItem sx={{ py: 2 }}>
                        <ListItemText
                          primary={
                            <Typography variant="subtitle1" fontWeight="medium">
                              {lab.name}
                            </Typography>
                          }
                          secondary={
                            <Typography variant="body2" color="text.secondary">
                              {lab.description}
                            </Typography>
                          }
                        />
                        <Button
                          variant="contained"
                          size="small"
                          onClick={() => handleReserveLab(lab.id)}
                        >
                          Reserve
                        </Button>
                      </ListItem>
                      {index < popularEquipment.length - 1 && <Divider />}
                    </Box>
                  ))
                ) : (
                  <ListItem>
                    <ListItemText 
                      primary={
                        <Typography variant="body1" align="center" sx={{ py: 2 }}>
                          No lab available
                        </Typography>
                      } 
                    />
                  </ListItem>
                )}

             <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
                <Button 
                  fullWidth 
                  variant="text" 
                  endIcon={<ArrowForwardIcon />}
                  onClick={() => navigate('/labs')}
                >
                  Browse All Labs
                </Button>
              </Box>
            
              </List>
              
            </Paper>
          ) : (
            <Paper sx={{ p: 0, height: '100%', overflow: 'hidden' }}>
              
              <Box sx={{ p: 2, bgcolor: theme.palette.primary.main, color: theme.palette.primary.contrastText }}>
                <Typography variant="h6" fontWeight="bold">
                  Upcoming Equipment Maintenance
                </Typography>
              </Box>
              <List sx={{ p: 0, height: '300px', overflow: 'auto' }}>
                {upcomingMaintenance.length > 0 ? (
                  upcomingMaintenance.map((maintenance, index) => (
                    <Box key={maintenance.id}>
                      <ListItem sx={{ py: 2 }}>
                        <Box sx={{ 
                          mr: 2, 
                          p: 1, 
                          bgcolor: 'primary.light', 
                          borderRadius: 1,
                          minWidth: '80px',
                          textAlign: 'center'
                        }}>
                          <Typography variant="body2" fontWeight="bold">
                            {format(new Date(maintenance.scheduled_date), 'MMM d')}
                          </Typography>
                        </Box>
                        <ListItemText
                          primary={
                            <Typography variant="subtitle1" fontWeight="medium">
                              {maintenance.equipment.name}
                            </Typography>
                          }
                          secondary={
                            <Typography variant="body2" color="text.secondary">
                              {maintenance.type} • {maintenance.status}
                            </Typography>
                          }
                        />
                        <Chip 
                          label={maintenance.status} 
                          color={
                            maintenance.status === 'scheduled' ? 'primary' :
                            maintenance.status === 'in_progress' ? 'warning' :
                            maintenance.status === 'completed' ? 'success' : 'default'
                          }
                          size="small"
                        />
                      </ListItem>
                      {index < upcomingMaintenance.length - 1 && <Divider />}
                    </Box>
                  ))
                ) : (
                  <ListItem>
                    <ListItemText 
                      primary={
                        <Typography variant="body1" align="center" sx={{ py: 2 }}>
                          No upcoming maintenance scheduled
                        </Typography>
                      } 
                    />
                  </ListItem>
                )}
                  <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
                    <Button 
                      fullWidth 
                      variant="text" 
                      endIcon={<ArrowForwardIcon />}
                      onClick={() => navigate(user?.role === 'admin' ? '/admin?tab=4' : '/lab_manager?tab=2')}
                    >
                      View All Maintenance
                    </Button>
                  </Box>
              </List>
              
              <Box sx={{ p: 2, bgcolor: theme.palette.primary.main, color: theme.palette.primary.contrastText }}>
                <Typography variant="h6" fontWeight="bold">
                  Upcoming Lab Maintenance
                </Typography>
              </Box>
              <List sx={{ p: 0, height: '300px', overflow: 'auto' }}>
                {upcomingLabMaintenance.length > 0 ? (
                  upcomingLabMaintenance.map((maintenance, index) => (
                    <Box key={maintenance.id}>
                      <ListItem sx={{ py: 2 }}>
                        <Box sx={{ 
                          mr: 2, 
                          p: 1, 
                          bgcolor: 'primary.light', 
                          borderRadius: 1,
                          minWidth: '80px',
                          textAlign: 'center'
                        }}>
                          <Typography variant="body2" fontWeight="bold">
                            {format(new Date(maintenance.scheduled_date), 'MMM d')}
                          </Typography>
                        </Box>
                        <ListItemText
                          primary={
                            <Typography variant="subtitle1" fontWeight="medium">
                              {maintenance.lab.name}
                            </Typography>
                          }
                          secondary={
                            <Typography variant="body2" color="text.secondary">
                              {maintenance.type} • {maintenance.status}
                            </Typography>
                          }
                        />
                        <Chip 
                          label={maintenance.status} 
                          color={
                            maintenance.status === 'scheduled' ? 'primary' :
                            maintenance.status === 'in_progress' ? 'warning' :
                            maintenance.status === 'completed' ? 'success' : 'default'
                          }
                          size="small"
                        />
                      </ListItem>
                      {index < upcomingLabMaintenance.length - 1 && <Divider />}
                    </Box>
                  ))
                ) : (
                  <ListItem>
                    <ListItemText 
                      primary={
                        <Typography variant="body1" align="center" sx={{ py: 2 }}>
                          No upcoming lab maintenance scheduled
                        </Typography>
                      } 
                    />
                  </ListItem>
                )}
                <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
                  <Button 
                    fullWidth 
                    variant="text" 
                    endIcon={<ArrowForwardIcon />}
                    onClick={() => navigate(user?.role === 'admin' ? '/admin?tab=4' : '/lab_manager?tab=2')}
                  >
                    View All Lab Maintenance
                  </Button>
                </Box>
              </List>
            </Paper>
          )}
        </Grid>
        <Grid>

        </Grid>
      </Grid>
    </Container>
  );
}

