import { equipmentService } from './equipmentService';
import { labService } from './labService';

let autoReleaseInterval: NodeJS.Timeout | null = null;

export const startAutoRelease = (intervalMinutes: number = 5) => {
  if (autoReleaseInterval) {
    clearInterval(autoReleaseInterval);
  }

  // Convert minutes to milliseconds
  const interval = intervalMinutes * 60 * 1000;

   // Validate interval
   if (intervalMinutes < 1) {
    console.warn('Interval must be at least 1 minute, setting to default 5 minutes');
    intervalMinutes = 5;
  }
  // Immediately check for releases
  equipmentService.checkAndUpdateEquipmentStatus()
    .then(result => {
      if (!result.success) {
        console.error('Initial auto-release check failed:', result.error);
      } else if ((result.releasedCount ?? 0) > 0) {
        console.log(`Released ${result.releasedCount} equipment items`);
      }
    });

  autoReleaseInterval = setInterval(async () => {
    try {
      // Auto-release equipment
      const equipmentResult = await equipmentService.checkAndUpdateEquipmentStatus();
      if (!equipmentResult.success) {
        console.error('Auto-release check for equipment failed:', equipmentResult.error);
      } else if ((equipmentResult.releasedCount ?? 0) > 0) {
        console.log(`Released ${equipmentResult.releasedCount} equipment items`);
      }

      // Auto-release labs
      const labResult = await labService.checkAndUpdateLabStatus();
      if (!labResult.success) {
        console.error('Auto-release check for labs failed:', labResult.error);
      } else if ((labResult.releasedCount ?? 0) > 0) {
        console.log(`Released ${labResult.releasedCount} labs`);
      }
    } catch (error) {
      console.error('An error occurred during auto-release process:', error);
    }
  }, interval);

  return () => {
    if (autoReleaseInterval) {
      clearInterval(autoReleaseInterval);
      autoReleaseInterval = null;
    }
  };
};

// Export function to manually trigger a release check
export const checkAndRelease = async () => {
  try {
    return await equipmentService.checkAndUpdateEquipmentStatus();
  } catch (error) {
    console.error('Error in manual release check:', error);
    throw error;
  }
};