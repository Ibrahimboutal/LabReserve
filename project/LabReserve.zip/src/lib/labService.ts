import { supabase } from './supabase';
import {  isAfter } from 'date-fns';

export const labService = {
  /**
   * Check and update lab status based on reservation times
   */
  async checkAndUpdateLabStatus() {
    try {
      // Get all approved lab reservations
      const { data: reservations, error: reservationsError } = await supabase
        .from('lab_reservations')
        .select(`
          id,
          lab_id,
          end_time,
          status
        `)
        .eq('status', 'approved');

      if (reservationsError) throw reservationsError;

      const now = new Date();
      // Add 15 minutes buffer time (unused variable removed)

      // Get lab IDs that need to be released
      const labToRelease = reservations
        ?.filter(reservation => isAfter(now, new Date(reservation.end_time)))
        .map(reservation => reservation.lab_id) || [];

      if (labToRelease.length > 0) {
        // Update equipment status to operational
        const { error: updateError } = await supabase
          .from('lab')
          .update({ status: 'operational' })
          .in('id', labToRelease)
          .eq('status', 'in_use');

        if (updateError) throw updateError;

        // Update lab reservation status to completed
        const { error: reservationUpdateError } = await supabase
          .from('lab_reservations')
          .update({ 
            status: 'completed',
            updated_at: new Date().toISOString()
          })
          .in('lab_id', labToRelease)
          .eq('status', 'approved');

        if (reservationUpdateError) throw reservationUpdateError;
      }

      return {
        success: true,
        releasedCount: labToRelease.length
      };
    } catch (error) {
      console.error('Error in checkAndUpdateEquipmentStatus:', error);
      return {
        success: false,
        error
      };
    }
  },

  /**
   * Update lab status when reservation is approved
   */
  async updateLabStatusOnReservation(labId: string, status: 'in_use' | 'operational') {
    try {
      const { error } = await supabase
        .from('lab')
        .update({ status })
        .eq('id', labId);

      if (error) throw error;

      return { success: true };
    } catch (error) {
      console.error('Error updating lab status:', error);
      return { success: false, error };
    }
  }
};