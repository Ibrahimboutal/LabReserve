import { supabase } from './supabase';
import { isAfter } from 'date-fns';
import type { Equipment } from '@/types'; // Adjust the import path as necessary

export const equipmentService = {
  /**
   * Check and update equipment status based on reservation times
   */
  async checkAndUpdateEquipmentStatus() {
    try {
      // Get all approved reservations
      const { data: reservations, error: reservationsError } = await supabase
        .from('reservations')
        .select(`
          id,
          equipment_id,
          end_time,
          status
        `)
        .eq('status', 'approved');

      if (reservationsError) throw reservationsError;

      const now = new Date();

      // Get equipment IDs that need to be released
      const equipmentToRelease = reservations
        ?.filter(reservation => isAfter(now, new Date(reservation.end_time)))
        .map(reservation => reservation.equipment_id) || [];

      if (equipmentToRelease.length > 0) {
        // Update equipment status to operational
        const { error: updateError } = await supabase
          .from('equipment')
          .update({ status: 'operational' })
          .in('id', equipmentToRelease)
          .eq('status', 'in_use');

        if (updateError) throw updateError;

        // Update reservation status to completed
        const { error: reservationUpdateError } = await supabase
          .from('reservations')
          .update({ 
            status: 'completed',
            updated_at: new Date().toISOString()
          })
          .in('equipment_id', equipmentToRelease)
          .eq('status', 'approved');

        if (reservationUpdateError) throw reservationUpdateError;
      }

      return {
        success: true,
        releasedCount: equipmentToRelease.length
      };
    } catch (error) {
      console.error('Error in checkAndUpdateEquipmentStatus:', error);
      return {
        success: false,
        error
      };
    }
  },

  /**
   * Update equipment status when reservation is approved
   */
  async updateEquipmentStatusOnReservation(equipmentId: string, status: 'in_use' | 'operational') {
    try {
      const { error } = await supabase
        .from('equipment')
        .update({ status })
        .eq('id', equipmentId);

      if (error) throw error;

      return { success: true };
    } catch (error) {
      console.error('Error updating equipment status:', error);
      return { success: false, error };
    }
  },


  /**
   * Get equipment availability for a given time period
   */
  async checkEquipmentAvailability(equipmentId: string, startTime: Date, endTime: Date) {
    try {
      const { data: conflicts, error } = await supabase
        .from('reservations')
        .select('*')
        .eq('equipment_id', equipmentId)
        .eq('status', 'approved')
        .or(`start_time.lte.${endTime.toISOString()},end_time.gte.${startTime.toISOString()}`);

      if (error) throw error;

      return {
        available: !conflicts || conflicts.length === 0,
        conflicts
      };
    } catch (error) {
      console.error('Error checking equipment availability:', error);
      throw error;
    }
  },

  /**
   * Get equipment with their current status and upcoming reservations
   */
  async getEquipmentWithStatus(): Promise<Equipment[]> {
    try {
      const { data, error } = await supabase
        .from('equipment')
        .select(`
          *,
          reservations (
            id,
            start_time,
            end_time,
            status
          )
        `)
        .order('name');

      if (error) throw error;

      return data || [];
    } catch (error) {
      console.error('Error fetching equipment with status:', error);
      throw error;
    }
  }
};