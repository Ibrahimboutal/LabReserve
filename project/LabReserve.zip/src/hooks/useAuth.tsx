import { useState, useEffect, createContext, useContext } from 'react';
import { supabase } from '@/lib/supabase';
import { users } from '@/types';

interface AuthContextType {
  user: users | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, department: string) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updatePassword: (newPassword: string) => Promise<void>;
  resendConfirmation: (email: string) => Promise<void>;
  
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<users | null>(null);
  const [loading, setLoading] = useState(true); 

  useEffect(() => {
    // Check active sessions and sets the user
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        fetchUser(session.user.id);
      }
      setLoading(false); 
    });

    // Listen for auth changes
    const { data: subscription } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        fetchUser(session.user.id);
      } else {
        setUser(null);
      }
      setLoading(false); 
    });

    return () => {
      subscription.subscription?.unsubscribe();
    };
  }, []);

  const fetchUser = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();
  
      if (error) {
        console.error('Error fetching user:', error);
        setUser(null);
        return;
      }
  
      if (data) {
        setUser(data as users);
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error('Error in fetchUser:', error);
      setUser(null);
    }
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;
    // Wait for user data to be fetched
    await new Promise<void>((resolve) => {
      const subscription = supabase.auth.onAuthStateChange(async (event, session) => {
        if (event === 'SIGNED_IN' && session?.user) {
          await fetchUser(session.user.id);
          subscription.data.subscription.unsubscribe();
          resolve();
        }
      });
    });
  };

  const signUp = async (email: string, password: string, department: string) => {
    const { data: { user: authUser }, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    if (signUpError) throw signUpError;
    if (!authUser?.id) throw new Error('Failed to create user');

    try {
      // Create user profile
      const { error: profileError } = await supabase
        .from('users')
        .insert([
          {
            id: authUser.id,
            email,
            role: 'student', // Default role
            department,
          },
        ]);

      if (profileError) throw profileError;
    } catch (error) {
      // If profile creation fails, attempt to delete the auth user
      await supabase.auth.admin.deleteUser(authUser.id);
      throw error;
    }
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    setUser(null);
  };

  const resetPassword = async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    });
    if (error) throw error;
  };

  const updatePassword = async (newPassword: string) => {
    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    });
    if (error) throw error;
  };

  const resendConfirmation = async (email: string) => {
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) throw error;
  };
  // Context value
  // Context value
  // Context value

  const value = {
    user,
    loading,
    signIn,
    signUp,
    signOut,
    resetPassword,
    updatePassword,
    resendConfirmation,
  };
  if (loading) {
    return <div>Loading...</div>; // Show a loading spinner while checking auth state
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;

 
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}